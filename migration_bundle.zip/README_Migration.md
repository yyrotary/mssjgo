# Migration Guide

1. Install PDF2JPG dependencies:
npm install pdfjs-dist@^5.5.207 jszip file-saver lucide-react framer-motion
npm install -D @types/file-saver @types/pdfjs-dist

2. Install Web Scraper dependencies:
npm install puppeteer turndown turndown-plugin-gfm robots-parser
npm install -D @types/turndown

3. Copy the 'src' folder into your target Next.js App Router project.